# Change Log

## [0.0.2] 2021-03-30
### Fixes and improvements

- Added flask message after save
- Patch #1 - Routing Error after install
- Patch #2 - Add flash message to page after saving

## [0.0.1] 2021-03-29

- Initial stable release
