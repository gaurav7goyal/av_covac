# -*- encoding: utf-8 -*-
"""
Copyright (c) 2021 - AR
"""



from django.apps import AppConfig

class AuthConfig(AppConfig):
    name = 'authcfg'
