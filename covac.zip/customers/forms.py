import pdb
import random
from django import forms

from customers.models import Profile,Vacinated


class ProfileForm(forms.ModelForm):
    first_name = forms.CharField(max_length=255)
    last_name = forms.CharField(max_length=255)
    email = forms.EmailField()

    class Meta:
        model = Profile
        fields = '__all__'
        exclude = ['user']


def form_validation_error(form):
    msg = ""
    for field in form:
        for error in field.errors:
            msg += "%s: %s \\n" % (field.label if hasattr(field, 'label') else 'Error', error)
    return msg

class vaccineSlotForm(forms.ModelForm):
    class Meta:
        model = Vacinated
        fields = ['vaccine_date','Slot']

    

    def randomnumber(self,N):
        minimum = pow(10, N-1)
        maximum = pow(10, N) - 1
        return random.randint(minimum, maximum)

    def save(self):
        vaccine_date  = self.cleaned_data.get('vaccine_date')
        Slot = self.cleaned_data.get('Slot')
        inst  = Vacinated.objects.create(user_profile = self.instance,vaccine_date =vaccine_date ,rfId =self.randomnumber(10) )
        inst.Slot = Slot
        inst.save()