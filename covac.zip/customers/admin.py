from django.contrib import admin

from customers.models import Profile , Vacinated
from django.contrib.auth.admin import UserAdmin



@admin.register(Profile)
class CustomUserAdmin(admin.ModelAdmin):
    search_fields = ['phone','aadharno']
    list_display = ( 'full_name','phone','aadharno','is_vacinated', )

@admin.register(Vacinated)
class VacinatedAdmin(admin.ModelAdmin):
    list_display = ( 'vacinated_person','vaccine_name','vaccine_date','Vacinated_by' )