from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.utils.decorators import method_decorator
from django.views import View
import io
from django.http import FileResponse
from reportlab.pdfgen import canvas

from customers.forms import ProfileForm, form_validation_error,vaccineSlotForm
from customers.models import Profile,Vacinated

from io import BytesIO
from django.http import HttpResponse
from django.template.loader import get_template

from xhtml2pdf import pisa

def render_to_pdf(template_src, context_dict={}):
    template = get_template(template_src)
    html  = template.render(context_dict)
    result = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)
    if not pdf.err:
        return HttpResponse(result.getvalue(), content_type='application/pdf')
    return None

@method_decorator(login_required(login_url='login'), name='dispatch')
class ProfileView(View):
    profile = None

    def dispatch(self, request, *args, **kwargs):
        self.profile, __ = Profile.objects.get_or_create(user=request.user)
        return super(ProfileView, self).dispatch(request, *args, **kwargs)

    def get(self, request):
        context = {'profile': self.profile, 'segment': 'profile'}
        return render(request, 'customers/profile.html', context)

    def post(self, request):
        form = ProfileForm(request.POST, request.FILES, instance=self.profile)

        if form.is_valid():
            profile = form.save()
            profile.user.first_name = form.cleaned_data.get('first_name')
            profile.user.last_name = form.cleaned_data.get('last_name')
            profile.user.email = form.cleaned_data.get('email')
            profile.user.save()

            messages.success(request, 'Profile saved successfully')
        else:
            messages.error(request, form_validation_error(form))
        return redirect('profile')

@method_decorator(login_required(login_url='login'), name='dispatch')
class vaccine_slot(View):
    def dispatch(self, request, *args, **kwargs):
        self.profile, __ = Profile.objects.get_or_create(user=request.user)
        return super(vaccine_slot, self).dispatch(request, *args, **kwargs)

    def get(self, request):
        vaccine_slot_data  =  Vacinated.objects.filter(user_profile = self.profile)
        slot_book_status =  vaccine_slot_data.exists()
        context = { 'form': vaccineSlotForm(),'data' :vaccine_slot_data,'status':slot_book_status}
        return render(request, 'customers/vaccine_slot.html', context)

    def post(self, request):
        form = vaccineSlotForm(request.POST,instance=self.profile)

        if form.is_valid():
            form.save()
           
            messages.success(request, 'Slot saved successfully')
        else:
            messages.error(request, form_validation_error(form))
        return redirect('slot')

@method_decorator(login_required(login_url='login'), name='dispatch')
class Vaccine_certificate(View):
    def dispatch(self, request, *args, **kwargs):
        self.profile, __ = Profile.objects.get_or_create(user=request.user)
        return super(Vaccine_certificate, self).dispatch(request, *args, **kwargs)
        
        
    def get(self, request):
        # Create a file-like buffer to receive PDF data.
        if self.profile.is_vacinated:
            
            data = {
            'name':self.profile.user.first_name+" "+self.profile.user.last_name,    
            'vaccine_name': self.profile.vacinated.vaccine_name,
            'vaccine_date': self.profile.vacinated.vaccine_date,
            'Vacinated_by': self.profile.vacinated.Vacinated_by,
            }
            pdf = render_to_pdf('customers/certificate.html', data)
            if pdf:
                response = HttpResponse(pdf, content_type='application/pdf')
                filename = "Certificate%s.pdf" %(self.profile.user.first_name+" "+self.profile.user.last_name)
                content = "attachment; filename='%s'" %(filename)
                response['Content-Disposition'] =content
                return response
        else:
            messages.error(request, "User not vacinated till now")
            return redirect('slot')



