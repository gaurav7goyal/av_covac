from django.urls import path
from customers import views

urlpatterns = [
    path('profile/', views.ProfileView.as_view(), name='profile'),
    path('vaccine_slot/', views.vaccine_slot.as_view(), name='slot'),
    path('certificate/', views.Vaccine_certificate.as_view(), name='certificate'),

]
