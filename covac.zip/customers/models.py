from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import gettext as _
from django.core.validators import RegexValidator

from django.contrib.staticfiles.templatetags.staticfiles import static


class Profile(models.Model):
    GENDER_MALE = 1
    GENDER_FEMALE = 2
    GENDER_CHOICES = [
        (GENDER_MALE, _("Male")),
        (GENDER_FEMALE, _("Female")),
    ]

    user = models.OneToOneField(User, related_name="profile", on_delete=models.CASCADE)
    avatar = models.ImageField(upload_to="customers/profiles/avatars/", null=True, blank=True)
    birthday = models.DateField(null=True, blank=True)
    gender = models.PositiveSmallIntegerField(choices=GENDER_CHOICES, null=True, blank=True)
    phone = models.CharField(max_length=32, null=True, blank=True)
    aadharno = models.CharField( max_length=12,validators=[RegexValidator(r'^\d{0,13}$')],blank=True)

    address = models.CharField(max_length=255, null=True, blank=True)
    number = models.CharField(max_length=32, null=True, blank=True)
    city = models.CharField(max_length=50, null=True, blank=True)
    zip = models.CharField(max_length=30, null=True, blank=True)
    is_vacinated =  models.BooleanField(default=False)


    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _('Profile')
        verbose_name_plural = _('Profiles')
    
    def __str__(self):
        return self.user.username
    
    @property
    def full_name(self):
        return self.user.first_name+" "+self.user.last_name
    @property
    def get_avatar(self):
        return self.avatar.url if self.avatar else static('assets/img/team/default-profile-picture.png')

class Vacinated(models.Model):

    VACCINE_CHOICES = (
        ('covaxin', 'covaxin'),
        ('covishield', 'covishield'),
        ('sputnik v vaccine','sputnik v vaccine')
    )
    user_profile = models.OneToOneField(Profile, on_delete=models.CASCADE)
    rfId = models.CharField(max_length=100, blank=False)
    vaccine_name =  models.CharField(max_length=20, choices=VACCINE_CHOICES)
    vaccine_date =  models.DateField(blank=False)
    status =    models.BooleanField(default=False)

    Slot =  models.CharField(max_length=50)
    center_name = models.CharField(max_length=100)
    Vacinated_by = models.CharField(max_length=50)

    @property
    def vacinated_person(self):
        return self.user_profile.full_name
    